import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['font.size'] = 12
plt.rcParams['axes.unicode_minus'] = True
plt.rcParams['lines.linewidth'] = 1
pd.set_option('display.max_columns',None)
pd.set_option('display.max_rows',None)

# 参数设置
lookback_days = 160  # 由于数据收集的原因最好不要修改此参数，否则组合开始的日期会变化
low_amplitude_threshold = 0.7
top_n_stocks = 30


# 数据读取
df_index = pd.read_csv('df_index.csv', index_col='trade_date', parse_dates=True) # 沪深300
df_close = pd.read_csv('index_close.csv', index_col='trade_date', parse_dates=True) # 成分股每日收盘价
df_low = pd.read_csv('index_low.csv', index_col='trade_date', parse_dates=True) # 成分股每日最低价
df_high = pd.read_csv('index_high.csv', index_col='trade_date', parse_dates=True) # 成分股每日最高价

df_close = df_close.join(df_index, how='outer')

# 去除交易数据空缺值太多的股票
threshold = 0.02

# 计算每列的空缺值比例
na_ratio = df_close.isna().mean()

# 删除空缺值比例大于阈值的列
df_close = df_close.loc[:, na_ratio <= threshold]
df_high = df_high.loc[:, na_ratio <= threshold]
df_low = df_low.loc[:, na_ratio <= threshold]

df_index = df_close[['CSI300']]
df_close = df_close.drop(columns=['CSI300'])

# 计算指数净值
df_rt = df_close.pct_change()
df_index['daily_return'] = df_index['CSI300'].pct_change()
df_index_start = df_index.iloc[lookback_days-1:].copy()
df_index_start['net_value'] = (1 + df_index_start['daily_return']).cumprod()
df_index_start['net_value'].iloc[0] = 1.0


# 构建动量组合 ###########################################################################################################

def find_previous_date(index, target_date):
    """
    在索引中找到比目标日期小的最近有效日期
    """
    previous_dates = index[index <= target_date]
    if len(previous_dates) > 0:
        return previous_dates[-1]  # 返回最后一个
    else:
        raise ValueError(f"No valid date found before {target_date}")


def calculate_long_term_momentum(df_close, df_high, df_low, lookback_days=160, low_amplitude_threshold=0.7):

    """
    计算长端动量因子
    """
    # 步骤1: 计算每日的涨跌幅（使用收盘价）
    df_returns = df_close.pct_change()

    # 步骤2: 计算每日的振幅（最高价/最低价 - 1）
    df_high, df_low = df_high.align(df_low, join='inner', axis=0)
    df_amplitude = (df_high / df_low) - 1

    # 步骤3: 获取最近lookback_days个交易日的数据
    start_date = df_amplitude.index[-1] - pd.Timedelta(days=lookback_days)
    lookback_amplitude = df_amplitude.loc[start_date:]

    # 存储每只股票的动量因子
    stock_factors = {}

    # 对每只股票进行处理
    for stock in lookback_amplitude.columns:
        # 选择振幅较低的n%交易日
        low_amplitude_days = lookback_amplitude[stock].nsmallest(
            int(len(lookback_amplitude[stock]) * low_amplitude_threshold)
        ).index

        # 计算这些选定日期的涨跌幅并加总
        selected_returns = df_returns.loc[low_amplitude_days, stock].sum()

        # 将该股票的动量因子存储起来
        stock_factors[stock] = selected_returns

    return pd.Series(stock_factors)



# 提取每月末有效日期
monthly_dates = df_high.resample('M').last().index

monthly_momentum_factors = {}
valid_date_close_list = []
selected_stocks_df = pd.DataFrame()

for date in monthly_dates:
    # 查找前一个有效日期（如月底缺失）
    try:
        valid_date_close = find_previous_date(df_close.index, date)
        valid_date_high = find_previous_date(df_high.index, date)
        valid_date_low = find_previous_date(df_low.index, date)
    except ValueError as e:
        print(e)
        continue

    valid_date_close_list.append(valid_date_close)

    # 计算长端动量因子
    momentum_factors = calculate_long_term_momentum(
        df_close.loc[:valid_date_close],
        df_high.loc[:valid_date_high],
        df_low.loc[:valid_date_low],
        lookback_days=lookback_days,
        low_amplitude_threshold=low_amplitude_threshold
    )

    # 存储动量因子
    monthly_momentum_factors[valid_date_close] = momentum_factors

    # 选择动量因子最高的前 N 只股票
    selected_stocks = momentum_factors.nlargest(top_n_stocks).index

    # 将当前 valid_date_close 的 5 只股票存入 DataFrame
    selected_stocks_df.loc[valid_date_close, range(1, top_n_stocks + 1)] = selected_stocks.values

# 给列命名
selected_stocks_df.columns = [f"Stock {i}" for i in range(1, top_n_stocks + 1)]
selected_stocks_df.index.name = "Valid Date"

# 每个月选取的股票
# print(selected_stocks_df)
selected_stocks_df.to_csv('selected_stocks.csv', index=True)

# 计算动量组合的每日净值
net_value = [1]

# 遍历 df_rt 的索引
for date in df_rt.iloc[lookback_days:].index:

    if date in selected_stocks_df.index:
        print(f"{date}: 更新组合")
        nv = net_value[-1]*(1+df_rt.loc[date, selected_stocks_df.loc[date]].mean())
    else:
        # print(f"{date}: 不更新组合")
        previous_valid_date = selected_stocks_df.index[selected_stocks_df.index < date].max()
        nv = net_value[-1]*(1+df_rt.loc[date, selected_stocks_df.loc[previous_valid_date]].mean())

    net_value.append(nv)

net_value = pd.Series(net_value, index=df_rt.iloc[lookback_days-1:].index)


# print(net_value) #动量组合的净值
# print(df_index_start['net_value']) #沪深300的净值


# 可视化动量组合和沪深300净值 ##############################################################################################

fig, ax1 = plt.subplots(figsize=(12, 6))

ax1.plot(net_value, color='darkblue', label='动量30',zorder=3,linewidth=1.5)
ax1.plot(df_index_start['net_value'], color='darkred', label='沪深300',zorder=3,linewidth=1.5)

ax2 = ax1.twinx()
ax2.fill_between(df_index_start.index, 0, net_value / df_index_start['net_value'],
                 color='grey', alpha=0.2, linewidth=0, label='动量30/沪深300',zorder=2)

ax1.axhline(y=1, color='black', linestyle='--')
ax2.axhline(y=1, color='darkgrey', linestyle='--')
ax1.legend(loc='upper left', frameon=False)
ax2.legend(loc='best', frameon=False)
ax1.set_title('投资组合净值')
ax1.set_ylabel('每日净值')
ax2.set_ylabel('动量30/沪深300')
ax2.set_ylim(0, (net_value / df_index_start['net_value']).max() * 1.1)

plt.margins(x=0)
plt.tight_layout()
plt.savefig('Net_Value.png', dpi=400)
# plt.show()


net_value = pd.Series(net_value)  # 投资组合的净值序列
csi300_net_value = pd.Series(df_index_start['net_value'])  # CSI300的净值序列

# 计算每日收益率
portfolio_returns = net_value.pct_change().dropna()
csi300_returns = csi300_net_value.pct_change().dropna()

# 指标计算函数
def calculate_metrics(net_value, daily_returns, risk_free_rate=0.02, freq=252):
    annual_return = (net_value.iloc[-1] / net_value.iloc[0]) ** (freq / len(net_value)) - 1
    volatility = daily_returns.std() * np.sqrt(freq)
    sharpe_ratio = (daily_returns.mean() - risk_free_rate / freq) / daily_returns.std() * np.sqrt(freq)
    sortino_ratio = (daily_returns.mean() - risk_free_rate / freq) / daily_returns[daily_returns < 0].std() * np.sqrt(freq)
    max_drawdown = ((net_value / net_value.cummax()) - 1).min()
    calmar_ratio = annual_return / abs(max_drawdown)
    win_rate = (daily_returns > 0).sum() / len(daily_returns)
    drawdown = (net_value / net_value.cummax()) - 1
    return {
        "Annual Return": annual_return,
        "Volatility": volatility,
        "Sharpe Ratio": sharpe_ratio,
        "Sortino Ratio": sortino_ratio,
        "Max Drawdown": max_drawdown,
        "Calmar Ratio": calmar_ratio,
        "Win Rate": win_rate,
        "Drawdown": drawdown,
    }

# 计算投资组合和CSI300的指标
portfolio_metrics = calculate_metrics(net_value, portfolio_returns)
csi300_metrics = calculate_metrics(csi300_net_value, csi300_returns)

print("==== 动量30 Metrics ====")
print(pd.DataFrame(portfolio_metrics, index=[0]).T)
print("==== 沪深300 Metrics ====")
print(pd.DataFrame(csi300_metrics, index=[0]).T)


# 保存比率
with open("portfolio_metrics.txt", "w") as f:
    f.write("动量30 Metrics:\n")
    f.write(pd.DataFrame(portfolio_metrics, index=[0]).T.to_string())  # 将DataFrame转换为字符串写入
    f.write("\n\n沪深300 Metrics:\n")
    f.write(pd.DataFrame(csi300_metrics, index=[0]).T.to_string())  # 同上

# 可视化
plt.figure(figsize=(16, 12))

# 子图1：净值曲线
plt.subplot(4, 2, 1)
plt.plot(net_value, label='动量30', color='darkblue', linewidth=2)
plt.plot(csi300_net_value, label='沪深300', color='darkred', linewidth=2)
plt.title('净值比较')
plt.margins(x=0)
plt.legend(frameon=False)

# 子图2：滚动波动率
plt.subplot(4, 2, 2)
rolling_volatility_portfolio = portfolio_returns.rolling(window=3).std() * np.sqrt(252)
rolling_volatility_csi300 = csi300_returns.rolling(window=3).std() * np.sqrt(252)
plt.plot(rolling_volatility_portfolio, label='动量30', color='darkblue')
plt.plot(rolling_volatility_csi300, label='沪深300', color='darkred')
plt.title('滚动波动率 (3天) 比较')
plt.margins(x=0)
plt.legend(frameon=False)

# 子图3：最大回撤
plt.subplot(4, 2, 3)
plt.plot(portfolio_metrics["Drawdown"], label='动量30', color='darkblue', linewidth=1.2)
plt.fill_between(net_value.index, 0, portfolio_metrics["Drawdown"], color='darkblue', alpha=0.3)
plt.plot(csi300_metrics["Drawdown"], label='沪深300', color='darkred', linewidth=1.2)
plt.fill_between(net_value.index, 0, csi300_metrics["Drawdown"], color='darkred', alpha=0.3)
plt.title('回撤比较')
plt.margins(x=0)
plt.axhline(0, color='black', linewidth=1, linestyle='--', alpha=0.6)
plt.legend(frameon=False)

# 子图4：最大回撤柱状图
plt.subplot(4, 2, 4)
sharpe_ratios = [portfolio_metrics["Max Drawdown"], csi300_metrics["Max Drawdown"]]
labels = ['动量30', '沪深300']
plt.bar(labels, sharpe_ratios, color=['darkblue', 'darkred'], alpha=0.7)
plt.axhline(y=0, color='black', linestyle='--')
plt.title('最大回撤比较')

# 子图5：夏普比率柱状图
plt.subplot(4, 2, 5)
sharpe_ratios = [portfolio_metrics["Sharpe Ratio"], csi300_metrics["Sharpe Ratio"]]
plt.bar(labels, sharpe_ratios, color=['darkblue', 'darkred'], alpha=0.7)
plt.axhline(y=0, color='black', linestyle='--')
plt.title('夏普比率 (Sharpe) 比较')

# 子图6：索比诺比率柱状图
plt.subplot(4, 2, 6)
sharpe_ratios = [portfolio_metrics["Sortino Ratio"], csi300_metrics["Sortino Ratio"]]
plt.bar(labels, sharpe_ratios, color=['darkblue', 'darkred'], alpha=0.7)
plt.axhline(y=0, color='black', linestyle='--')
plt.title('索比诺比率 (Sortino) 比较')

# 子图7：卡玛比率柱状图
plt.subplot(4, 2, 7)
calmar_ratios = [portfolio_metrics["Calmar Ratio"], csi300_metrics["Calmar Ratio"]]
plt.bar(labels, calmar_ratios, color=['darkblue', 'darkred'], alpha=0.7)
plt.axhline(y=0, color='black', linestyle='--')
plt.title('卡玛比率 (Calmar) 比较')

# 子图8：胜率柱状图
plt.subplot(4, 2, 8)
win_rates = [portfolio_metrics["Win Rate"], csi300_metrics["Win Rate"]]
plt.bar(labels, win_rates, color=['darkblue', 'darkred'], alpha=0.7)
plt.title('胜率比较')

# 调整布局并显示
plt.tight_layout()
plt.savefig('Comparison.png', dpi=400)
plt.show()