import tushare as ts
import pandas as pd

pro = ts.pro_api('20241124210121-584f5f8b-ebd1-4508-aeb3-434ef64cf790')
pro._DataApi__http_url = 'http://tsapi.majors.ltd:7000'

start_date='20211231'
end_date='20241215'

df_index = pro.index_daily(ts_code='399300.SZ', start_date=start_date, end_date=end_date)
df_index = df_index[['trade_date', 'close']]
df_index = df_index.set_index('trade_date').sort_index()
df_index = df_index.rename(columns={'close': 'CSI300'})

# 获取指数成分股代码
index_weight = pro.index_weight(index_code='399300.SZ', start_date='20240930', end_date='20240930')
stock_codes = index_weight['con_code'].tolist()

all_data_close = pd.DataFrame()
all_data_high = pd.DataFrame()
all_data_low = pd.DataFrame()

# 计数器初始化
# 获取指数成分股的数据
total_stocks = len(stock_codes)  # 总股票数
for idx, code in enumerate(stock_codes, start=1):
    try:
        print(f"正在获取第 {idx}/{total_stocks} 只股票 ({code}) 的数据...")
        stock_data = pro.daily(ts_code=code, start_date=start_date, end_date=end_date)

        # 如果返回为空，跳过当前股票
        if stock_data.empty:
            print(f"{code} 无数据，跳过...")
            continue

        stock_data = stock_data[['trade_date','close','high','low']]
        stock_data = stock_data.set_index('trade_date').sort_index()

        sd_close = stock_data[['close']]
        sd_high = stock_data[['high']]
        sd_low = stock_data[['low']]

        stock_data_close = sd_close.rename(columns={'close': f'{code}'})
        stock_data_high = sd_high.rename(columns={'high': f'{code}'})
        stock_data_low = sd_low.rename(columns={'low': f'{code}'})

        all_data_close = all_data_close.join(stock_data_close, how='outer')
        all_data_high = all_data_high.join(stock_data_high, how='outer')
        all_data_low = all_data_low.join(stock_data_low, how='outer')

    except Exception as e:
        print(f"获取 {code} 时出错：{e}")
        continue

print(f"已获取数据记录数：{len(all_data_close)}")

# 保存成分股数据到 CSV 文件
all_data_close.to_csv('index_close.csv', index=True)
all_data_high.to_csv('index_high.csv', index=True)
all_data_low.to_csv('index_low.csv', index=True)

# 保存指数数据到 CSV 文件
df_index.to_csv('df_index.csv', index=True)

print("所有数据已获取并保存")
